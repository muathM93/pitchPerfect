//
//  RecordSoundsViewController.swift
//  pitchPerfect
//
//  Created by Muath Mohammed on 14/01/1441 AH.
//  Copyright © 1441 MuathMohammed. All rights reserved.
//

import UIKit
import AVFoundation
class RecordSoundsViewController: UIViewController , AVAudioRecorderDelegate {

    
    
    var audioRecorder: AVAudioRecorder!
    @IBOutlet weak var recordingButton     : UIButton!
    @IBOutlet weak var recordingLable      : UILabel!
    @IBOutlet weak var stopRecordingButton : UIButton!
    
    
    // MARK: this function to unable stop button, once the app open

    override func viewDidLoad() {
        super.viewDidLoad()
        stopRecordingButton.isEnabled   = false
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        print("viewWillAppear")
    }
    

    @IBAction func recordAudio(_ sender: Any)
    {
        stopRecordingButton.isEnabled   = true
        recordingButton.isEnabled       = false
        recordingLable.text             = "Recording in Progress"
        
        let dirPath = NSSearchPathForDirectoriesInDomains(.documentDirectory,.userDomainMask, true)[0] as String
        let recordingName = "recordedVoice.wav"
        let pathArray = [dirPath, recordingName]
        let filePath  = URL(string: pathArray.joined(separator: "/"))
        let session = AVAudioSession.sharedInstance()
        
        try! session.setCategory(AVAudioSession.Category.playAndRecord, mode: AVAudioSession.Mode.default, options: AVAudioSession.CategoryOptions.defaultToSpeaker)
        try! audioRecorder = AVAudioRecorder(url: filePath!, settings: [:])
        audioRecorder.delegate = self
        audioRecorder.isMeteringEnabled = true
        audioRecorder.prepareToRecord()
        audioRecorder.record()
    }
    
    @IBAction func stopRecording(_ sender: Any) {
        
        stopRecordingButton.isEnabled   = false
        recordingButton.isEnabled       = true
        recordingLable.text             = "Tap to Record"
        audioRecorder.stop()
        let audioSession                = AVAudioSession.sharedInstance()
        try! audioSession.setActive(false)
        
    }
    
    // MARK: this function to pass a sound throw Segue

    func audioRecorderDidFinishRecording(_ recorder: AVAudioRecorder, successfully flag: Bool) {
        if flag {
            performSegue(withIdentifier: "stopRecording", sender: audioRecorder.url)
        } else {
            print("Recording Failed")
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "stopRecording"
        {
            let playSoundVC = segue.destination as! PlaySoundViewController
            let recoredAudioURL = sender as! URL
            playSoundVC.recordedAudioURL = recoredAudioURL
            
        }
    }
}



